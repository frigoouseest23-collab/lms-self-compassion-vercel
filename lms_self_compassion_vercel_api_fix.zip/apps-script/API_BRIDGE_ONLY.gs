/**
 * VERCEL API BRIDGE
 * Dipakai saat frontend LMS di-hosting di Vercel.
 * Frontend Vercel memanggil /api/apps-script, lalu proxy Vercel meneruskan request ke doPost ini.
 */
function doPost(e) {
  try {
    const request = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(request.action || '').trim();
    const args = Array.isArray(request.args) ? request.args : [];

    const allowedActions = {
      loginUser: loginUser,
      registerUser: registerUser,
      verifyOtp: verifyOtp,
      resendOtp: resendOtp,

      getModulesForPage: getModulesForPage,
      getProgressOnlyByIdentityPatch: getProgressOnlyByIdentityPatch,
      saveProgressOnlyByIdentityPatch: saveProgressOnlyByIdentityPatch,

      saveJournalReflection: saveJournalReflection,
      saveExerciseReflection: saveExerciseReflection,
      createReminder: createReminder,
      disableReminder: disableReminder,

      updateStudentProfilePatch: updateStudentProfilePatch,
      changeStudentPasswordPatch: changeStudentPasswordPatch
    };

    if (!action || !allowedActions[action]) {
      return createJsonResponse_({
        success: false,
        message: 'Action API tidak dikenal: ' + action
      });
    }

    const result = allowedActions[action].apply(null, args);

    return createJsonResponse_(result);

  } catch (error) {
    return createJsonResponse_({
      success: false,
      message: 'API Apps Script error: ' + error.message
    });
  }
}

function createJsonResponse_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}



function testVercelApiBridge() {
  const mockEvent = {
    postData: {
      contents: JSON.stringify({
        action: 'getModulesForPage',
        args: []
      })
    }
  };

  const response = doPost(mockEvent);
  const content = response.getContent();

  console.log(content);
  return content;
}
