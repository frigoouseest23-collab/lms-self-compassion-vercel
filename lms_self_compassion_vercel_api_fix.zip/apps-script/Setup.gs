function setupDatabase() {
  const ss = getSpreadsheet_();

  setupUsersSheet_(ss);
  setupModulesSheet_(ss);
  setupLessonsSheet_(ss);
  setupExercisesSheet_(ss);
  setupJournalsSheet_(ss);
  setupUserProgressSheet_(ss);
  setupRemindersSheet_(ss);

  seedInitialLmsData_(ss);

  SpreadsheetApp.flush();

  return 'Setup database LMS Self-Compassion berhasil dibuat.';
}

function setupUsersSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.USERS, USER_HEADERS, '#EDE9FE');
}

function setupModulesSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.MODULES, MODULE_HEADERS, '#DCFCE7');
}

function setupLessonsSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.LESSONS, LESSON_HEADERS, '#DBEAFE');
}

function setupExercisesSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.EXERCISES, EXERCISE_HEADERS, '#FEF3C7');
}

function setupJournalsSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.JOURNALS, JOURNAL_HEADERS, '#FCE7F3');
}

function setupUserProgressSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.USER_PROGRESS, USER_PROGRESS_HEADERS, '#E0E7FF');
}

function setupRemindersSheet_(ss) {
  setupSheet_(ss, APP_CONFIG.SHEETS.REMINDERS, REMINDER_HEADERS, '#CCFBF1');
}

function setupSheet_(ss, sheetName, headers, bgColor) {
  let sheet = ss.getSheetByName(sheetName);

  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }

  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.setFrozenRows(1);

  sheet.getRange(1, 1, 1, headers.length)
    .setFontWeight('bold')
    .setBackground(bgColor)
    .setFontColor('#1F2937')
    .setHorizontalAlignment('center');

  sheet.autoResizeColumns(1, headers.length);
}

function seedInitialLmsData_(ss) {
  seedModules_(ss);
  seedLessons_(ss);
  seedExercises_(ss);
}

function seedModules_(ss) {
  const sheet = ss.getSheetByName(APP_CONFIG.SHEETS.MODULES);

  if (sheet.getLastRow() >= 2) {
    return;
  }

  const now = new Date();

  sheet.getRange(2, 1, 6, MODULE_HEADERS.length).setValues([
    [
      'MOD-001',
      1,
      'Mengenal Tekanan Akademik',
      'Siswa memahami stres akademik yang muncul saat mempersiapkan ujian masuk PTN.',
      'ARTIKEL_INTERAKTIF',
      'ACTIVE',
      now,
      now
    ],
    [
      'MOD-002',
      2,
      'Memahami Self-Compassion',
      'Siswa mengenal konsep self-kindness, common humanity, dan mindfulness.',
      'ARTIKEL_INTERAKTIF',
      'ACTIVE',
      now,
      now
    ],
    [
      'MOD-003',
      3,
      'Latihan Self-Kindness',
      'Siswa belajar mengubah kritik diri menjadi dukungan diri yang realistis.',
      'GUIDED_EXERCISE',
      'ACTIVE',
      now,
      now
    ],
    [
      'MOD-004',
      4,
      'Mindfulness Saat Tertekan',
      'Siswa berlatih menyadari emosi dan pikiran tanpa menghakimi diri sendiri.',
      'AUDIO_EXERCISE',
      'ACTIVE',
      now,
      now
    ],
    [
      'MOD-005',
      5,
      'Menghadapi Rasa Gagal',
      'Siswa belajar menerima kegagalan sebagai bagian dari proses persiapan ujian.',
      'REFLECTION',
      'ACTIVE',
      now,
      now
    ],
    [
      'MOD-006',
      6,
      'Membangun Kepercayaan Diri',
      'Siswa menyusun rencana belajar yang lebih sehat dan penuh welas asih pada diri.',
      'QUIZ_REFLEKSI',
      'ACTIVE',
      now,
      now
    ]
  ]);
}

function seedLessons_(ss) {
  const sheet = ss.getSheetByName(APP_CONFIG.SHEETS.LESSONS);

  if (sheet.getLastRow() >= 2) {
    return;
  }

  const now = new Date();

  sheet.getRange(2, 1, 12, LESSON_HEADERS.length).setValues([
    [
      'LES-001',
      'MOD-001',
      1,
      'Apa itu Tekanan Akademik?',
      'ARTIKEL',
      'Tekanan akademik adalah kondisi ketika siswa merasa terbebani oleh tuntutan belajar, ekspektasi nilai, persaingan, dan ketakutan gagal menghadapi ujian masuk PTN.',
      '',
      5,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-002',
      'MOD-001',
      2,
      'Mengenali Tanda Stres',
      'ARTIKEL',
      'Stres dapat muncul dalam bentuk sulit tidur, mudah marah, sulit fokus, merasa tidak mampu, atau terus membandingkan diri dengan orang lain.',
      '',
      5,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-003',
      'MOD-002',
      1,
      'Apa itu Self-Compassion?',
      'ARTIKEL',
      'Self-compassion adalah kemampuan memperlakukan diri dengan hangat, sadar, dan manusiawi saat mengalami kesulitan.',
      '',
      6,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-004',
      'MOD-002',
      2,
      'Tiga Komponen Self-Compassion',
      'ARTIKEL',
      'Self-compassion terdiri dari self-kindness, common humanity, dan mindfulness.',
      '',
      6,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-005',
      'MOD-003',
      1,
      'Mengubah Kritik Diri',
      'GUIDED_EXERCISE',
      'Tuliskan satu kalimat kritik diri yang sering muncul, lalu ubah menjadi kalimat dukungan yang lebih realistis.',
      '',
      8,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-006',
      'MOD-003',
      2,
      'Surat untuk Diri Sendiri',
      'GUIDED_EXERCISE',
      'Bayangkan sahabatmu mengalami hal yang sama. Tuliskan nasihat hangat yang juga bisa kamu berikan kepada dirimu.',
      '',
      10,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-007',
      'MOD-004',
      1,
      'Latihan Napas 3 Menit',
      'AUDIO',
      'Ambil posisi nyaman. Tarik napas perlahan, sadari tubuhmu, lalu lepaskan ketegangan sedikit demi sedikit.',
      '',
      3,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-008',
      'MOD-004',
      2,
      'Menyadari Emosi Tanpa Menghakimi',
      'GUIDED_EXERCISE',
      'Amati emosi yang muncul hari ini. Beri nama emosi itu tanpa menyalahkan diri.',
      '',
      5,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-009',
      'MOD-005',
      1,
      'Gagal Bukan Akhir',
      'ARTIKEL',
      'Rasa gagal adalah pengalaman manusiawi. Dalam proses belajar, gagal dapat menjadi informasi untuk memperbaiki strategi.',
      '',
      6,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-010',
      'MOD-005',
      2,
      'Refleksi Pengalaman Sulit',
      'REFLECTION',
      'Ceritakan satu pengalaman akademik yang berat dan apa hal kecil yang bisa kamu pelajari darinya.',
      '',
      10,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-011',
      'MOD-006',
      1,
      'Kepercayaan Diri yang Realistis',
      'ARTIKEL',
      'Percaya diri bukan berarti selalu yakin akan berhasil, tetapi percaya bahwa diri mampu berusaha, belajar, dan bangkit.',
      '',
      6,
      'ACTIVE',
      now,
      now
    ],
    [
      'LES-012',
      'MOD-006',
      2,
      'Rencana Belajar Welas Asih',
      'QUIZ_REFLEKSI',
      'Susun satu target belajar kecil yang realistis dan satu bentuk dukungan untuk dirimu sendiri.',
      '',
      10,
      'ACTIVE',
      now,
      now
    ]
  ]);
}

function seedExercises_(ss) {
  const sheet = ss.getSheetByName(APP_CONFIG.SHEETS.EXERCISES);

  if (sheet.getLastRow() >= 2) {
    return;
  }

  const now = new Date();

  sheet.getRange(2, 1, 4, EXERCISE_HEADERS.length).setValues([
    [
      'EXC-001',
      'MOD-003',
      'LES-005',
      'SELF_REFLECTION',
      'Apa kalimat kritik diri yang sering muncul saat kamu merasa gagal belajar?',
      'Tuliskan dengan jujur, lalu coba ubah menjadi kalimat yang lebih mendukung.',
      'ACTIVE',
      now,
      now
    ],
    [
      'EXC-002',
      'MOD-004',
      'LES-007',
      'MINDFULNESS',
      'Apa yang kamu rasakan setelah mengambil jeda napas selama 3 menit?',
      'Fokus pada sensasi tubuh, pikiran, dan emosi yang muncul.',
      'ACTIVE',
      now,
      now
    ],
    [
      'EXC-003',
      'MOD-005',
      'LES-010',
      'SELF_REFLECTION',
      'Apa satu pengalaman akademik sulit yang masih membekas?',
      'Ceritakan tanpa menghakimi diri. Fokus pada proses dan pelajaran yang muncul.',
      'ACTIVE',
      now,
      now
    ],
    [
      'EXC-004',
      'MOD-006',
      'LES-012',
      'ACTION_PLAN',
      'Apa satu target belajar kecil yang ingin kamu lakukan besok?',
      'Buat target yang realistis, spesifik, dan tidak menyakiti diri sendiri.',
      'ACTIVE',
      now,
      now
    ]
  ]);
}
